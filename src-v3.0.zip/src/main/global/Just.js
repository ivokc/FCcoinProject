import {FunctionalManager,UIManager} from '../manager/Manager';

global.Just = {
    ...FunctionalManager,
    ...UIManager
}
