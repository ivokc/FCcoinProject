import {userReducer,capReducer} from '../sys/vendor/dataflow/Reducer';
import {bankAcctReducer} from '../business-module/user/vendor/dataflow/Reducer';



export default {
    userReducer,
    bankAcctReducer,
    capReducer
}
