

const DialogUtility = {

  //
  showLoading(o){
    Constant.showLoading = true;
  },
  dismissLoading(o){
    Constant.showLoading = false;
  }
  
}

export default DialogUtility; 