import { NativeModules } from 'react-native';

export const ScanModule = NativeModules.ScanModule;
