import AutoHideKeyboard from '../component/decorator/AutoHideKeyboard';
import CommonHead from '../component/decorator/CommonHead';
global.AutoHideKeyboard = AutoHideKeyboard;
global.CommonHead = CommonHead;
